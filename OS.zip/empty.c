#include <stdio.h>
int main(){
	printf("Jai shree Ram");
	return 0;
	
}
